package com.webelements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReadTestEle6 {
	WebDriver driver ;
	 
	 public ReadTestEle6(WebDriver driver) {
		 this.driver=driver;
		 PageFactory.initElements(driver, this);
	 }
	 
	 @FindBy(id=("user-name"))public WebElement username6;
	 @FindBy(id=("password"))public WebElement password6;
	 @FindBy(xpath=("//input[@type='submit']"))public WebElement login6;
	 @FindBy(id=("add-to-cart-sauce-labs-backpack"))public WebElement addtocart6;
}

